package tutorial.blocks;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
public class BlockCopperOre extends Block{
	public Hashtable<Integer,HashSet<BlockPos>> aa;
	public static Integer delayDivisor;
	public int delay;
	public BlockCopperOre(String unlocalizedName) {
		super(Material.rock);
		this.setUnlocalizedName(unlocalizedName);
		aa = new Hashtable<Integer, HashSet<BlockPos>>();
		delayDivisor = (int) 10;
		delay = 8;

		// TODO Auto-generated constructor stub
	}

    /**
     * Called When an Entity Collided with the Block
     */


    public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn)
    {

//		System.out.print("\n:");
//
//		System.out.print(entityIn.getClass().getSimpleName());
//		System.out.print(":\n");



    	if (entityIn.getClass().getSimpleName().equals("EntityPlayerMP") ||entityIn.getClass().getSimpleName().equals("EntityPlayerSP") ){

    		//add the blocks to current time set in the dictionary
    		int thisTime = (int) (worldIn.getWorldTime()/delayDivisor) ;
        	if (aa.containsKey(thisTime)){
        		aa.get(thisTime).add(pos);

        	}
        	else {
            	HashSet<BlockPos> h = new HashSet<BlockPos>();
            	h.add(pos);
        		aa.put(thisTime,h);
        	}


        	//loop through time and remove by time set
        	int previous = thisTime - delay;
        	while (aa.containsKey(previous)){
        		Iterator<BlockPos> it = aa.get(previous).iterator();
        		while (it.hasNext()){
        	    	BlockPos p = it.next();
    				worldIn.destroyBlock(p, false);
        		}
        		aa.remove(previous);
        		previous--;

        	}
    	}


    }

    public AxisAlignedBB getCollisionBoundingBox(World worldIn, BlockPos pos, IBlockState state)
    {
        float f = 0.0625F;
        return new AxisAlignedBB((double)((float)pos.getX() + f), (double)pos.getY(), (double)((float)pos.getZ() + f), (double)((float)(pos.getX() + 1) - f), (double)((float)(pos.getY() + 1) - f), (double)((float)(pos.getZ() + 1) - f));
    }

    @SideOnly(Side.CLIENT)
    public AxisAlignedBB getSelectedBoundingBox(World worldIn, BlockPos pos)
    {
        float f = 0.0625F;
        return new AxisAlignedBB((double)((float)pos.getX() + f), (double)pos.getY(), (double)((float)pos.getZ() + f), (double)((float)(pos.getX() + 1) - f), (double)(pos.getY() + 1), (double)((float)(pos.getZ() + 1) - f));
    }

}
