package tutorial.proxy;

public class commonProxy {
		public void registerRenders(){
			
		}
}
