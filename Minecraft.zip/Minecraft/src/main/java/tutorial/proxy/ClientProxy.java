package tutorial.proxy;

import tutorial.init.tutorialBlock;
import tutorial.init.tutorialItems;

public class ClientProxy extends commonProxy {
	@Override
	public void registerRenders(){
		tutorialItems.registerRenders();
		tutorialBlock.registerRenders();
	}
}
