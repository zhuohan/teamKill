package tutorial.init;

import tutorial.Reference;
import tutorial.blocks.BlockCopperOre;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class tutorialBlock {
	
	public static Block test_block;
	
	public static void init(){
		test_block = new BlockCopperOre("test_block");
		
	}
	public static void register(){
		registerBlock(test_block);
	}
	private static void registerBlock(Block block) {
		// TODO Auto-generated method stub
		GameRegistry.registerBlock(block, block.getUnlocalizedName().substring(5));
		System.out.println("registed block");
	}
	public static void registerRenders(){
		registerRender(test_block);
	}
	
	public static void registerRender(Block block){
		Item item = Item.getItemFromBlock(block);
//		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().r
		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, 0, 
				new ModelResourceLocation(Reference.MOD_ID + ":"+ item.getUnlocalizedName().substring(5), "inventory"));
		
	}
	
	
	
	
	
}
